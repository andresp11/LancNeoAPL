using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace LancNeo
{
	/// <summary>
	/// Descripci�n breve de Respaldo.
	/// </summary>
	public class Respaldo : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label2;
		private System.Data.SqlClient.SqlConnection sqlConn;
		private System.Data.SqlClient.SqlCommand sqlCommand1;
		private System.Windows.Forms.Label label1;
		protected Soluciones2000.Tools.WinLib.tbBtn btnVistaPrevia;
		public System.Data.SqlClient.SqlDataAdapter sqlDABusObraO;
		public System.Data.SqlClient.SqlDataAdapter sqlDABusObraD;
		private System.Data.SqlClient.SqlCommand sqlCommand2;
		private System.Windows.Forms.ComboBox cmbIdObraO;
		private System.Windows.Forms.ComboBox cmbIdObrad;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label4;
		protected Soluciones2000.Tools.WinLib.tbBtn tbBtn1;
		private LancNeo.dsRespaldoObra dsRespaldoObra1;
		private LancNeo.dsRespaldoObra dsRespaldoObra2;
		private System.Windows.Forms.Panel panel3;
		protected Soluciones2000.Tools.WinLib.tbBtn tbBtn2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panel4;
		protected Soluciones2000.Tools.WinLib.tbBtn tbBtn3;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cmbElitrabajo;
		private System.Data.SqlClient.SqlCommand sqlComRespaldo;
		private System.Windows.Forms.ComboBox cmbElirespaldo;
		private System.Data.SqlClient.SqlCommand sqlComRestaura;
		private System.Data.SqlClient.SqlCommand sqlComBorra;
		private System.Data.SqlClient.SqlCommand sqlComBorracnal;
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Respaldo()
		{
			//
			// Necesario para admitir el Dise�ador de Windows Forms
			//
			InitializeComponent();

			//
			// TODO: agregar c�digo de constructor despu�s de llamar a InitializeComponent
			//
		}

		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region C�digo generado por el Dise�ador de Windows Forms
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Respaldo));
            System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVistaPrevia = new Soluciones2000.Tools.WinLib.tbBtn();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbIdObraO = new System.Windows.Forms.ComboBox();
            this.dsRespaldoObra1 = new LancNeo.dsRespaldoObra();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbIdObrad = new System.Windows.Forms.ComboBox();
            this.dsRespaldoObra2 = new LancNeo.dsRespaldoObra();
            this.sqlConn = new System.Data.SqlClient.SqlConnection();
            this.sqlDABusObraO = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDABusObraD = new System.Data.SqlClient.SqlDataAdapter();
            this.sqlCommand2 = new System.Data.SqlClient.SqlCommand();
            this.sqlComRespaldo = new System.Data.SqlClient.SqlCommand();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbBtn1 = new Soluciones2000.Tools.WinLib.tbBtn();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbBtn2 = new Soluciones2000.Tools.WinLib.tbBtn();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbElitrabajo = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbBtn3 = new Soluciones2000.Tools.WinLib.tbBtn();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbElirespaldo = new System.Windows.Forms.ComboBox();
            this.sqlComRestaura = new System.Data.SqlClient.SqlCommand();
            this.sqlComBorra = new System.Data.SqlClient.SqlCommand();
            this.sqlComBorracnal = new System.Data.SqlClient.SqlCommand();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsRespaldoObra1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsRespaldoObra2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnVistaPrevia);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cmbIdObraO);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.Yellow;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(552, 72);
            this.panel1.TabIndex = 0;
            // 
            // btnVistaPrevia
            // 
            this.btnVistaPrevia.BackColor = System.Drawing.Color.Transparent;
            this.btnVistaPrevia.Icon = ((System.Drawing.Icon)(resources.GetObject("btnVistaPrevia.Icon")));
            this.btnVistaPrevia.Location = new System.Drawing.Point(478, 4);
            this.btnVistaPrevia.Name = "btnVistaPrevia";
            this.btnVistaPrevia.Size = new System.Drawing.Size(64, 64);
            this.btnVistaPrevia.TabIndex = 13;
            this.btnVistaPrevia.Click += new System.EventHandler(this.btnVistaPrevia_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 24);
            this.label3.TabIndex = 14;
            this.label3.Text = "Respaldo de obras";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(210, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Obra a respaldar:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbIdObraO
            // 
            this.cmbIdObraO.DataSource = this.dsRespaldoObra1.Obra;
            this.cmbIdObraO.DisplayMember = "Idobra";
            this.cmbIdObraO.Location = new System.Drawing.Point(304, 14);
            this.cmbIdObraO.Name = "cmbIdObraO";
            this.cmbIdObraO.Size = new System.Drawing.Size(80, 21);
            this.cmbIdObraO.TabIndex = 9;
            this.cmbIdObraO.ValueMember = "IdObra";
            // 
            // dsRespaldoObra1
            // 
            this.dsRespaldoObra1.DataSetName = "dsRespaldoObra";
            this.dsRespaldoObra1.Locale = new System.Globalization.CultureInfo("es-MX");
            this.dsRespaldoObra1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(212, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Obra a restaurar:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbIdObrad
            // 
            this.cmbIdObrad.DataSource = this.dsRespaldoObra2.Obra;
            this.cmbIdObrad.DisplayMember = "Idobra";
            this.cmbIdObrad.Location = new System.Drawing.Point(304, 38);
            this.cmbIdObrad.Name = "cmbIdObrad";
            this.cmbIdObrad.Size = new System.Drawing.Size(80, 21);
            this.cmbIdObrad.TabIndex = 11;
            this.cmbIdObrad.ValueMember = "IdObra";
            // 
            // dsRespaldoObra2
            // 
            this.dsRespaldoObra2.DataSetName = "dsRespaldoObra";
            this.dsRespaldoObra2.Locale = new System.Globalization.CultureInfo("es-MX");
            this.dsRespaldoObra2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sqlConn
            // 
            this.sqlConn.ConnectionString = ((string)(configurationAppSettings.GetValue("sqlConn.ConnectionString", typeof(string))));
            this.sqlConn.FireInfoMessageEventOnUserErrors = false;
            // 
            // sqlDABusObraO
            // 
            this.sqlDABusObraO.SelectCommand = this.sqlCommand1;
            this.sqlDABusObraO.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "Obra", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Idobra", "Idobra"),
                        new System.Data.Common.DataColumnMapping("Ubicacion", "Ubicacion"),
                        new System.Data.Common.DataColumnMapping("RFC", "RFC"),
                        new System.Data.Common.DataColumnMapping("Facturar", "Facturar")})});
            // 
            // sqlCommand1
            // 
            this.sqlCommand1.CommandText = "SELECT Idobra, Ubicacion, RFC FROM Obra ORDER BY Idobra";
            this.sqlCommand1.Connection = this.sqlConn;
            // 
            // sqlDABusObraD
            // 
            this.sqlDABusObraD.SelectCommand = this.sqlCommand2;
            this.sqlDABusObraD.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "Obra", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("Idobra", "Idobra"),
                        new System.Data.Common.DataColumnMapping("Ubicacion", "Ubicacion"),
                        new System.Data.Common.DataColumnMapping("RFC", "RFC"),
                        new System.Data.Common.DataColumnMapping("Facturar", "Facturar")})});
            // 
            // sqlCommand2
            // 
            this.sqlCommand2.CommandText = "SELECT Idobra, Ubicacion, RFC FROM cnal.dbo.Obra ORDER BY Idobra";
            this.sqlCommand2.Connection = this.sqlConn;
            // 
            // sqlComRespaldo
            // 
            this.sqlComRespaldo.CommandText = "[respaldo]";
            this.sqlComRespaldo.CommandType = System.Data.CommandType.StoredProcedure;
            this.sqlComRespaldo.Connection = this.sqlConn;
            this.sqlComRespaldo.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((byte)(0)), ((byte)(0)), "", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@IdObra", System.Data.SqlDbType.NVarChar, 6)});
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.tbBtn1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbIdObrad);
            this.panel2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Location = new System.Drawing.Point(0, 76);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(552, 86);
            this.panel2.TabIndex = 1;
            // 
            // tbBtn1
            // 
            this.tbBtn1.BackColor = System.Drawing.Color.Transparent;
            this.tbBtn1.Icon = ((System.Drawing.Icon)(resources.GetObject("tbBtn1.Icon")));
            this.tbBtn1.Location = new System.Drawing.Point(478, 4);
            this.tbBtn1.Name = "tbBtn1";
            this.tbBtn1.Size = new System.Drawing.Size(64, 64);
            this.tbBtn1.TabIndex = 43;
            this.tbBtn1.Click += new System.EventHandler(this.tbBtn1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(4, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(220, 24);
            this.label4.TabIndex = 15;
            this.label4.Text = "Restauraci�n de obras";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.tbBtn2);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.cmbElitrabajo);
            this.panel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.panel3.Location = new System.Drawing.Point(0, 166);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(552, 86);
            this.panel3.TabIndex = 2;
            // 
            // tbBtn2
            // 
            this.tbBtn2.BackColor = System.Drawing.Color.Transparent;
            this.tbBtn2.Icon = ((System.Drawing.Icon)(resources.GetObject("tbBtn2.Icon")));
            this.tbBtn2.Location = new System.Drawing.Point(478, 4);
            this.tbBtn2.Name = "tbBtn2";
            this.tbBtn2.Size = new System.Drawing.Size(64, 64);
            this.tbBtn2.TabIndex = 43;
            this.tbBtn2.Click += new System.EventHandler(this.tbBtn2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(4, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(473, 24);
            this.label5.TabIndex = 15;
            this.label5.Text = "Eliminaci�n de obras en base de datos de trabajo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(212, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Obra a eliminar:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbElitrabajo
            // 
            this.cmbElitrabajo.DataSource = this.dsRespaldoObra1.Obra;
            this.cmbElitrabajo.DisplayMember = "Idobra";
            this.cmbElitrabajo.Location = new System.Drawing.Point(304, 38);
            this.cmbElitrabajo.Name = "cmbElitrabajo";
            this.cmbElitrabajo.Size = new System.Drawing.Size(80, 21);
            this.cmbElitrabajo.TabIndex = 11;
            this.cmbElitrabajo.ValueMember = "IdObra";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.tbBtn3);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.cmbElirespaldo);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Location = new System.Drawing.Point(0, 257);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(552, 86);
            this.panel4.TabIndex = 3;
            // 
            // tbBtn3
            // 
            this.tbBtn3.BackColor = System.Drawing.Color.Transparent;
            this.tbBtn3.Icon = ((System.Drawing.Icon)(resources.GetObject("tbBtn3.Icon")));
            this.tbBtn3.Location = new System.Drawing.Point(474, 33);
            this.tbBtn3.Name = "tbBtn3";
            this.tbBtn3.Size = new System.Drawing.Size(64, 46);
            this.tbBtn3.TabIndex = 43;
            this.tbBtn3.Click += new System.EventHandler(this.tbBtn3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(4, 4);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(491, 24);
            this.label7.TabIndex = 15;
            this.label7.Text = "Eliminaci�n de obras en base de datos de respaldo";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(212, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Obra a eliminar:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cmbElirespaldo
            // 
            this.cmbElirespaldo.DataSource = this.dsRespaldoObra2.Obra;
            this.cmbElirespaldo.DisplayMember = "Idobra";
            this.cmbElirespaldo.Location = new System.Drawing.Point(304, 38);
            this.cmbElirespaldo.Name = "cmbElirespaldo";
            this.cmbElirespaldo.Size = new System.Drawing.Size(80, 21);
            this.cmbElirespaldo.TabIndex = 11;
            this.cmbElirespaldo.ValueMember = "IdObra";
            // 
            // sqlComRestaura
            // 
            this.sqlComRestaura.CommandText = "[restaura]";
            this.sqlComRestaura.CommandType = System.Data.CommandType.StoredProcedure;
            this.sqlComRestaura.Connection = this.sqlConn;
            this.sqlComRestaura.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((byte)(0)), ((byte)(0)), "", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@IdObra", System.Data.SqlDbType.NVarChar, 6)});
            // 
            // sqlComBorra
            // 
            this.sqlComBorra.CommandText = "[Borra]";
            this.sqlComBorra.CommandType = System.Data.CommandType.StoredProcedure;
            this.sqlComBorra.Connection = this.sqlConn;
            this.sqlComBorra.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((byte)(0)), ((byte)(0)), "", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@IdObra", System.Data.SqlDbType.NVarChar, 6)});
            // 
            // sqlComBorracnal
            // 
            this.sqlComBorracnal.CommandText = "[borracnal]";
            this.sqlComBorracnal.CommandType = System.Data.CommandType.StoredProcedure;
            this.sqlComBorracnal.Connection = this.sqlConn;
            this.sqlComBorracnal.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((byte)(0)), ((byte)(0)), "", System.Data.DataRowVersion.Current, null),
            new System.Data.SqlClient.SqlParameter("@IdObra", System.Data.SqlDbType.NVarChar, 6)});
            // 
            // Respaldo
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(552, 343);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Respaldo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Respaldo";
            this.Load += new System.EventHandler(this.Respaldo_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dsRespaldoObra1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsRespaldoObra2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

		}
		#endregion

		private void Respaldo_Load(object sender, System.EventArgs e)
		{
			sqlDABusObraO.Fill(dsRespaldoObra1, "Obra");
			sqlDABusObraD.Fill(dsRespaldoObra2, "Obra");
		}

		private void btnVistaPrevia_Click(object sender, System.EventArgs e)
		{
			try
			{
				sqlConn.Open();
				sqlComRespaldo.Parameters["@IdObra"].Value = cmbIdObraO.SelectedValue;
				int error = sqlComRespaldo.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message );
			}
			sqlConn.Close();
			dsRespaldoObra1.Clear();
			dsRespaldoObra2.Clear();
			sqlDABusObraO.Fill(dsRespaldoObra1, "Obra");
			sqlDABusObraD.Fill(dsRespaldoObra2, "Obra");
		}

		private void tbBtn1_Click(object sender, System.EventArgs e)
		{
			try
			{
				sqlConn.Open();
				sqlComRestaura.Parameters["@IdObra"].Value = cmbIdObrad.SelectedValue;
				int error = sqlComRestaura.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message );
			}
			sqlConn.Close();
			dsRespaldoObra1.Clear();
			dsRespaldoObra2.Clear();
			sqlDABusObraO.Fill(dsRespaldoObra1, "Obra");
			sqlDABusObraD.Fill(dsRespaldoObra2, "Obra");
		}

		private void label7_Click(object sender, System.EventArgs e)
		{
		
		}

		private void tbBtn2_Click(object sender, System.EventArgs e)
		{
			try
			{
				sqlConn.Open();
				sqlComBorra.Parameters["@IdObra"].Value = cmbElitrabajo.SelectedValue;
				int error = sqlComBorra.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message );
			}
			sqlConn.Close();
			dsRespaldoObra1.Clear();
			dsRespaldoObra2.Clear();
			sqlDABusObraO.Fill(dsRespaldoObra1, "Obra");
			sqlDABusObraD.Fill(dsRespaldoObra2, "Obra");
		}

		private void tbBtn3_Click(object sender, System.EventArgs e)
		{
			try
			{
				sqlConn.Open();
				sqlComBorracnal.Parameters["@IdObra"].Value = cmbElirespaldo.SelectedValue;
				int error = sqlComBorracnal.ExecuteNonQuery();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message );
			}
			sqlConn.Close();
			dsRespaldoObra1.Clear();
			dsRespaldoObra2.Clear();
			sqlDABusObraO.Fill(dsRespaldoObra1, "Obra");
			sqlDABusObraD.Fill(dsRespaldoObra2, "Obra");
		}
	}
}

