﻿namespace LancNeo {
    
    
    public partial class dsAcero {
    }
}
namespace LancNeo {
    
    
    public partial class dsAcero {
    }
}
