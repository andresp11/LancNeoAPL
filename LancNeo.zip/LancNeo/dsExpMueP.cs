﻿namespace LancNeo {
    
    
    public partial class dsExpMueP {
        partial class MuestrasDataTable
        {
        }
    }
}
