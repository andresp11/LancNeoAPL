﻿namespace LancNeo {
    
    
    public partial class dsBusSolicitud {
    }
}
