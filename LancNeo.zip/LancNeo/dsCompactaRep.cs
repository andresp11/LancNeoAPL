﻿namespace LancNeo {
    
    
    public partial class dsCompactaRep {
    }
}
namespace LancNeo {
    
    
    public partial class dsCompactaRep {
    }
}
