﻿namespace LancNeo
{


    public partial class dsZeta
    {
    }
}
namespace LancNeo {
    
    
    public partial class dsZeta {
    }
}
