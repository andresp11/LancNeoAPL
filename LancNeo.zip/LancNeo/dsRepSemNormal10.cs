﻿namespace LancNeo {
    
    
    public partial class dsRepSemNormal10 {
    }
}
