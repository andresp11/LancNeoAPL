﻿namespace LancNeo {
    
    
    public partial class dsMuestra {
    }
}
namespace LancNeo {
    
    
    public partial class dsMuestra {
    }
}
