﻿namespace LancNeo {
    
    
    public partial class dsGrupos {
    }
}
namespace LancNeo {
    
    
    public partial class dsGrupos {
    }
}
