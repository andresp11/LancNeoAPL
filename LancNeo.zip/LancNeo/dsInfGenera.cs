﻿namespace LancNeo
{


    public partial class dsInfGenera
    {
    }
}
namespace LancNeo {
    
    
    public partial class dsInfGenera {
    }
}
