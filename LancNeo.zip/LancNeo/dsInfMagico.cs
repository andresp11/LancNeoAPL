﻿namespace LancNeo {
    
    
    public partial class dsInfMagico {
        partial class InfMagicoDataTable
        {
      }
    }
}
