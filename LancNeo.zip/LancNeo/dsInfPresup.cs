﻿namespace LancNeo
{
}

namespace LancNeo {
    
    
    public partial class dsInfPresup {
    }
}
namespace LancNeo {
    
    
    public partial class dsInfPresup {
    }
}
