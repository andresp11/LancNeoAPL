﻿namespace LancNeo
{
}

namespace LancNeo {
    
    
    public partial class dsRepNo10NCo {
    }
}
namespace LancNeo {
    
    
    public partial class dsRepNo10NCo {
    }
}
