﻿namespace LancNeo {
    
    
    public partial class dsCompactaMdor {
    }
}
namespace LancNeo {
    
    
    public partial class dsCompactaMdor {
    }
}
