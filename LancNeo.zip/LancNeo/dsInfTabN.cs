﻿namespace LancNeo {
    
    
    public partial class dsInfTabN {
        partial class TabRepN1DataTable
        {
        }
    }
}
