﻿namespace LancNeo {
    
    
    public partial class dsResBajo {
    }
}
namespace LancNeo {
    
    
    public partial class dsResBajo {
    }
}
