﻿namespace LancNeo
{


    public partial class dsAvance
    {
    }
}
namespace LancNeo {
    
    
    public partial class dsAvance {
    }
}
