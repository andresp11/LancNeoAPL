﻿namespace LancNeo {
    
    
    public partial class dsActividad {
    }
}
