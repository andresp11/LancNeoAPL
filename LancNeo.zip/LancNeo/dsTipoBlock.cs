﻿namespace LancNeo {
    
    
    public partial class dsTipoBlock {
    }
}
