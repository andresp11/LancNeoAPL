﻿namespace LancNeo {
    
    
    public partial class dcmfct_dbDataSet {
    }
}
