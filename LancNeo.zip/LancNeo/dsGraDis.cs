﻿namespace LancNeo {
    
    
    public partial class dsGraDis {
    }
}
namespace LancNeo {
    
    
    public partial class dsGraDis {
    }
}
