﻿namespace LancNeo {
    
    
    public partial class dsSoldaRep {
    }
}
