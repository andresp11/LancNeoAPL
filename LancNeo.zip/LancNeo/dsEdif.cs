﻿namespace LancNeo {
    
    
    public partial class dsEdif {
    }
}
namespace LancNeo {
    
    
    public partial class dsEdif {
    }
}
