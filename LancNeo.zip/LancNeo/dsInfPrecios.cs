﻿namespace LancNeo {
    
    
    public partial class dsInfPrecios {
    }
}
namespace LancNeo {
    
    
    public partial class dsInfPrecios {
    }
}
