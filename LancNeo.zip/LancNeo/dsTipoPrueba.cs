﻿namespace LancNeo {
    
    
    public partial class dsTipoPrueba {
    }
}
