﻿namespace LancNeo {
    
    
    public partial class dsAnalisis {
    }
}
namespace LancNeo {
    
    
    public partial class dsAnalisis {
    }
}
