﻿namespace LancNeo {
    
    
    public partial class dsTipo {
    }
}
