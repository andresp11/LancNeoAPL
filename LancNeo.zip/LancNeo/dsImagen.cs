﻿namespace LancNeo
{
}
namespace LancNeo
{


    public partial class dsImagen
    {
    }
}
namespace LancNeo {
    
    
    public partial class dsImagen {
    }
}
