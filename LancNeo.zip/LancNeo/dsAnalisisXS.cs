﻿namespace LancNeo {
    
    
    public partial class dsAnalisisXS {
    }
}
namespace LancNeo {
    
    
    public partial class dsAnalisisXS {
    }
}
