﻿namespace LancNeo {
    
    
    public partial class dsRepMuestreador {
    }
}
