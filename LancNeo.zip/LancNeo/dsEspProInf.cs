﻿namespace LancNeo
{


    public partial class dsEspProInf
    {
        partial class MuestrasDataTable
        {
        }
    }
}
