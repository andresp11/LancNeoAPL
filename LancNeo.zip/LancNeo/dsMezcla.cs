﻿namespace LancNeo {
    
    
    public partial class dsMezcla {
        partial class MezclaDataTable
        {
        }
    }
}
